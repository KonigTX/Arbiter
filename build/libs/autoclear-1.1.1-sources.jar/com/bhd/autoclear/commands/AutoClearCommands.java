package com.bhd.autoclear.commands;

import com.bhd.autoclear.config.ConfigManager;
import com.bhd.autoclear.core.ClearanceManager;
import com.bhd.autoclear.core.ItemScanner;
import com.bhd.autoclear.core.StatsTracker;
import com.bhd.autoclear.core.TpsTracker;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import me.lucko.fabric.api.permissions.v0.Permissions;
import java.util.stream.StreamSupport;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_124;
import net.minecraft.class_1937;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Optional;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/**
 * Registers the full {@code /autoclear} Brigadier command tree.
 *
 * <p>Command tree:
 * <pre>
 * /autoclear
 *   force                    — clear all loaded worlds immediately (autoclear.force, OP 4)
 *     [dimension]            — optional: e.g., "minecraft:the_nether"
 *   status                   — time until next clear, TPS, item counts (autoclear.status, OP 2)
 *   reload                   — reload config from disk (autoclear.reload, OP 4)
 *   stats                    — session statistics: clears run, items removed (autoclear.stats, OP 2)
 * </pre>
 *
 * <p>Permission nodes use {@link Permissions#require(String, int)} from fabric-permissions-api,
 * which bridges transparently to LuckPerms when present and falls back to OP-level checks otherwise.
 */
public final class AutoClearCommands {

    private static final Logger LOGGER = LoggerFactory.getLogger("AutoClear/Commands");

    // Permission nodes
    private static final String PERM_FORCE   = "autoclear.force";
    private static final String PERM_STATUS  = "autoclear.status";
    private static final String PERM_RELOAD  = "autoclear.reload";
    private static final String PERM_STATS   = "autoclear.stats";
    private static final String PERM_DRYRUN   = "autoclear.dryrun";
    private static final String PERM_TESTBAR  = "autoclear.testbar";
    private static final String PERM_MODE     = "autoclear.mode";

    // OP fallback levels
    private static final int OP_ADMIN  = 4;
    private static final int OP_VIEWER = 2;

    private AutoClearCommands() {
        // Static registration class — not instantiable
    }

    // ── Registration ──────────────────────────────────────────────────────────

    /**
     * Registers the command tree via {@link CommandRegistrationCallback}.
     * Call once during mod initialization, before the server starts.
     *
     * @param configManager    used by {@code reload} subcommand
     * @param clearanceManager used by {@code force} subcommand
     * @param statsTracker     used by {@code stats} subcommand
     * @param tpsTracker       used by {@code status} subcommand
     */
    public static void register(
            ConfigManager configManager,
            ClearanceManager clearanceManager,
            StatsTracker statsTracker,
            TpsTracker tpsTracker) {

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                buildTree(dispatcher, configManager, clearanceManager, statsTracker, tpsTracker));
    }

    // ── Tree construction ─────────────────────────────────────────────────────

    private static void buildTree(
            CommandDispatcher<class_2168> dispatcher,
            ConfigManager configManager,
            ClearanceManager clearanceManager,
            StatsTracker statsTracker,
            TpsTracker tpsTracker) {

        dispatcher.register(
            method_9247("autoclear")
                // No top-level execution — require a subcommand
                .then(buildForce(clearanceManager))
                .then(buildStatus(clearanceManager, tpsTracker))
                .then(buildReload(configManager, clearanceManager))
                .then(buildStats(statsTracker))
                .then(buildDryRun(clearanceManager))
                .then(buildTestBar(clearanceManager, configManager))
                .then(buildMode(configManager, clearanceManager))
        );

        LOGGER.debug("/autoclear command tree registered");
    }

    // ── /autoclear force [dimension] ──────────────────────────────────────────

    private static com.mojang.brigadier.builder.LiteralArgumentBuilder<class_2168> buildForce(
            ClearanceManager clearanceManager) {

        return method_9247("force")
            .requires(Permissions.require(PERM_FORCE, OP_ADMIN))
            .executes(ctx -> executeForceAll(ctx, clearanceManager))
            .then(
                method_9244("dimension", StringArgumentType.string())
                    .executes(ctx -> executeForceDimension(ctx, clearanceManager))
            );
    }

    private static int executeForceAll(CommandContext<class_2168> ctx, ClearanceManager clearanceManager) {
        MinecraftServer server = ctx.getSource().method_9211();
        ctx.getSource().method_9226(
            () -> class_2561.method_43470("Forcing item clear on all loaded worlds...").method_27692(class_124.field_1054), true);

        clearanceManager.forceAllWorlds(server);

        ctx.getSource().method_9226(
            () -> class_2561.method_43470("Item clear complete.").method_27692(class_124.field_1060), true);
        return 1;
    }

    private static int executeForceDimension(CommandContext<class_2168> ctx, ClearanceManager clearanceManager) {
        String dimensionStr = StringArgumentType.getString(ctx, "dimension");
        MinecraftServer server = ctx.getSource().method_9211();

        // Attempt to resolve the dimension identifier
        class_2960 dimensionId = class_2960.method_12829(dimensionStr);
        if (dimensionId == null) {
            ctx.getSource().method_9213(
                class_2561.method_43470("Invalid dimension identifier: '" + dimensionStr + "'"));
            return 0;
        }

        Optional<class_3218> worldOpt = StreamSupport.stream(server.method_3738().spliterator(), false)
                .filter(w -> w.method_27983().method_29177().equals(dimensionId))
                .findFirst();

        if (worldOpt.isEmpty()) {
            ctx.getSource().method_9213(
                class_2561.method_43470("Dimension not loaded or not found: '" + dimensionStr + "'"));
            return 0;
        }

        class_3218 world = worldOpt.get();
        ctx.getSource().method_9226(
            () -> class_2561.method_43470("Forcing item clear on dimension: " + dimensionStr).method_27692(class_124.field_1054),
            true);

        clearanceManager.forceWorld(world);

        ctx.getSource().method_9226(
            () -> class_2561.method_43470("Item clear complete.").method_27692(class_124.field_1060), true);
        return 1;
    }

    // ── /autoclear status ─────────────────────────────────────────────────────

    private static com.mojang.brigadier.builder.LiteralArgumentBuilder<class_2168> buildStatus(
            ClearanceManager clearanceManager,
            TpsTracker tpsTracker) {

        return method_9247("status")
            .requires(Permissions.require(PERM_STATUS, OP_VIEWER))
            .executes(ctx -> executeStatus(ctx, clearanceManager, tpsTracker));
    }

    private static int executeStatus(
            CommandContext<class_2168> ctx,
            ClearanceManager clearanceManager,
            TpsTracker tpsTracker) {

        MinecraftServer server = ctx.getSource().method_9211();
        double tps = tpsTracker.getCurrentTps();

        ctx.getSource().method_9226(
            () -> class_2561.method_43470("=== AutoClear Status ===").method_27692(class_124.field_1065), false);
        ctx.getSource().method_9226(
            () -> class_2561.method_43470("Current TPS: " + String.format("%.2f", tps))
                    .method_27692(tps >= 18.0 ? class_124.field_1060 : tps >= 14.0 ? class_124.field_1054 : class_124.field_1061),
            false);

        for (class_3218 world : server.method_3738()) {
            class_5321<class_1937> key = world.method_27983();
            String worldName = key.method_29177().toString();
            int secondsRemaining = clearanceManager.getSecondsUntilClear(key);
            int itemCount = ItemScanner.countAll(world);

            final String displayTime = secondsRemaining >= 0
                    ? secondsRemaining + "s"
                    : "pending";

            ctx.getSource().method_9226(
                () -> class_2561.method_43470("  [" + worldName + "] Next clear in: " + displayTime + " | Items on ground: " + itemCount)
                        .method_27692(class_124.field_1075),
                false);
        }
        return 1;
    }

    // ── /autoclear reload ─────────────────────────────────────────────────────

    private static com.mojang.brigadier.builder.LiteralArgumentBuilder<class_2168> buildReload(
            ConfigManager configManager,
            ClearanceManager clearanceManager) {

        return method_9247("reload")
            .requires(Permissions.require(PERM_RELOAD, OP_ADMIN))
            .executes(ctx -> executeReload(ctx, configManager, clearanceManager));
    }

    private static int executeReload(
            CommandContext<class_2168> ctx,
            ConfigManager configManager,
            ClearanceManager clearanceManager) {

        ctx.getSource().method_9226(
            () -> class_2561.method_43470("Reloading AutoClear configuration...").method_27692(class_124.field_1054), true);

        configManager.load();
        clearanceManager.resetAllCounters();

        ctx.getSource().method_9226(
            () -> class_2561.method_43470("AutoClear configuration reloaded successfully.").method_27692(class_124.field_1060), true);
        LOGGER.info("/autoclear reload executed by {}", ctx.getSource().method_9214());
        return 1;
    }

    // ── /autoclear stats ──────────────────────────────────────────────────────

    private static com.mojang.brigadier.builder.LiteralArgumentBuilder<class_2168> buildStats(
            StatsTracker statsTracker) {

        return method_9247("stats")
            .requires(Permissions.require(PERM_STATS, OP_VIEWER))
            .executes(ctx -> executeStats(ctx, statsTracker));
    }

    private static int executeStats(CommandContext<class_2168> ctx, StatsTracker statsTracker) {
        String statsOutput = statsTracker.getFormattedStats();
        // Split on newline and send each line as a separate feedback message
        for (String line : statsOutput.split("\n")) {
            final String finalLine = line;
            ctx.getSource().method_9226(
                () -> class_2561.method_43470(finalLine).method_27692(class_124.field_1068), false);
        }
        return 1;
    }

    // ── /autoclear dryrun [dimension] ────────────────────────────────────────

    private static com.mojang.brigadier.builder.LiteralArgumentBuilder<class_2168> buildDryRun(
            ClearanceManager clearanceManager) {

        return method_9247("dryrun")
            .requires(Permissions.require(PERM_DRYRUN, OP_VIEWER))
            .executes(ctx -> executeDryRunAll(ctx, clearanceManager))
            .then(
                method_9244("dimension", StringArgumentType.string())
                    .executes(ctx -> executeDryRunDimension(ctx, clearanceManager))
            );
    }

    private static int executeDryRunAll(
            CommandContext<class_2168> ctx, ClearanceManager clearanceManager) {

        MinecraftServer server = ctx.getSource().method_9211();
        ctx.getSource().method_9226(
            () -> class_2561.method_43470("[AutoClear DryRun] Scanning all loaded worlds...")
                    .method_27692(class_124.field_1065), false);

        for (class_3218 world : server.method_3738()) {
            ClearanceManager.DryRunResult result = clearanceManager.dryRun(world);
            sendDryRunFeedback(ctx.getSource(), world, result);
        }
        return 1;
    }

    private static int executeDryRunDimension(
            CommandContext<class_2168> ctx, ClearanceManager clearanceManager) {

        String dimensionStr = StringArgumentType.getString(ctx, "dimension");
        MinecraftServer server = ctx.getSource().method_9211();

        class_2960 dimensionId = class_2960.method_12829(dimensionStr);
        if (dimensionId == null) {
            ctx.getSource().method_9213(
                class_2561.method_43470("Invalid dimension identifier: '" + dimensionStr + "'"));
            return 0;
        }

        Optional<class_3218> worldOpt = StreamSupport.stream(server.method_3738().spliterator(), false)
                .filter(w -> w.method_27983().method_29177().equals(dimensionId))
                .findFirst();

        if (worldOpt.isEmpty()) {
            ctx.getSource().method_9213(
                class_2561.method_43470("Dimension not loaded or not found: '" + dimensionStr + "'"));
            return 0;
        }

        class_3218 world = worldOpt.get();
        ClearanceManager.DryRunResult result = clearanceManager.dryRun(world);
        sendDryRunFeedback(ctx.getSource(), world, result);
        return 1;
    }

    // ── /autoclear testbar [seconds] ─────────────────────────────────────────

    private static com.mojang.brigadier.builder.LiteralArgumentBuilder<class_2168> buildTestBar(
            ClearanceManager clearanceManager, ConfigManager configManager) {

        return method_9247("testbar")
            .requires(Permissions.require(PERM_TESTBAR, OP_ADMIN))
            .executes(ctx -> executeTestBar(ctx, clearanceManager, configManager, -1))
            .then(
                method_9244("seconds", IntegerArgumentType.integer(1, 300))
                    .executes(ctx -> executeTestBar(ctx, clearanceManager, configManager,
                            IntegerArgumentType.getInteger(ctx, "seconds")))
            );
    }

    private static int executeTestBar(
            CommandContext<class_2168> ctx,
            ClearanceManager clearanceManager,
            ConfigManager configManager,
            int secondsArg) {

        int seconds = secondsArg;
        if (seconds <= 0) {
            int configured = configManager.getResolvedConfig(net.minecraft.class_1937.field_25179).warningStartSeconds;
            seconds = configured > 0 ? configured : 10;
        }

        MinecraftServer server = ctx.getSource().method_9211();
        clearanceManager.startTestBar(server, seconds);

        final int finalSeconds = seconds;
        ctx.getSource().method_9226(
            () -> class_2561.method_43470("[AutoClear] Testbar started for " + finalSeconds + "s (no clear will fire).")
                    .method_27692(class_124.field_1075), false);
        return 1;
    }

    // ── /autoclear mode <modeName> ────────────────────────────────────────────

    private static com.mojang.brigadier.builder.LiteralArgumentBuilder<class_2168> buildMode(
            ConfigManager configManager, ClearanceManager clearanceManager) {

        return method_9247("mode")
            .requires(Permissions.require(PERM_MODE, OP_ADMIN))
            .then(
                method_9244("modeName", StringArgumentType.word())
                    .suggests((ctx, builder) -> {
                        for (String name : new String[]{"aggressive", "warden", "calm", "custom"}) {
                            builder.suggest(name);
                        }
                        return builder.buildFuture();
                    })
                    .executes(ctx -> executeMode(ctx, configManager, clearanceManager,
                            StringArgumentType.getString(ctx, "modeName")))
            );
    }

    private static int executeMode(
            CommandContext<class_2168> ctx,
            ConfigManager configManager,
            ClearanceManager clearanceManager,
            String modeName) {

        java.util.Set<String> valid = java.util.Set.of("aggressive", "warden", "calm", "custom");
        if (!valid.contains(modeName)) {
            ctx.getSource().method_9213(
                class_2561.method_43470("Unknown mode '" + modeName + "'. Valid modes: aggressive, warden, calm, custom"));
            return 0;
        }

        configManager.saveMode(modeName);
        configManager.load();
        clearanceManager.resetAllCounters();

        ctx.getSource().method_9226(
            () -> class_2561.method_43470("[AutoClear] Mode set to '" + modeName + "' — config reloaded.")
                    .method_27692(class_124.field_1060), true);
        return 1;
    }

    private static void sendDryRunFeedback(
            class_2168 source, class_3218 world, ClearanceManager.DryRunResult result) {

        String worldName = world.method_27983().method_29177().toString();

        // Header
        source.method_9226(
            () -> class_2561.method_43470("[AutoClear DryRun] " + worldName)
                    .method_27692(class_124.field_1075), false);

        // Total found
        final int totalFound = result.totalFound();
        source.method_9226(
            () -> class_2561.method_43470("  Total items found : " + totalFound)
                    .method_27692(class_124.field_1068), false);

        // Would clear / would protect
        final int wouldClear   = result.wouldClear();
        final int wouldProtect = result.wouldProtect();

        if (result.thresholdSkipped()) {
            source.method_9226(
                () -> class_2561.method_43470("  Would clear       : " + wouldClear)
                        .method_27692(class_124.field_1068), false);
            source.method_9226(
                () -> class_2561.method_43470("  Would protect     : " + wouldProtect)
                        .method_27692(class_124.field_1068), false);

            final int threshold = result.threshold();
            source.method_9226(
                () -> class_2561.method_43470("  Threshold check   : SKIPPED — "
                        + totalFound + " < " + threshold + " (itemCountThreshold)")
                        .method_27692(class_124.field_1054), false);
        } else {
            source.method_9226(
                () -> class_2561.method_43470("  Would CLEAR       : " + wouldClear + " items")
                        .method_27692(class_124.field_1061), false);
            source.method_9226(
                () -> class_2561.method_43470("  Would protect     : " + wouldProtect)
                        .method_27692(class_124.field_1068), false);
        }

        // Protection breakdown header
        source.method_9226(
            () -> class_2561.method_43470("  Protection breakdown:")
                    .method_27692(class_124.field_1080), false);

        // Per-rule lines (all entries, including zeros)
        for (java.util.Map.Entry<String, Integer> entry : result.protectionBreakdown().entrySet()) {
            final String label = entry.getKey();
            final int count = entry.getValue();
            // "cleared" is not a protection rule — skip it in the protection block
            if ("cleared".equals(label)) continue;
            source.method_9226(
                () -> class_2561.method_43470("    " + label + " : " + count)
                        .method_27692(class_124.field_1068), false);
        }
    }
}
