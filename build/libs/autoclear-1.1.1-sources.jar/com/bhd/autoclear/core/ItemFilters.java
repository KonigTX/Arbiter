package com.bhd.autoclear.core;

import com.bhd.autoclear.config.ItemTier;
import com.bhd.autoclear.config.ResolvedConfig;
import java.util.List;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_7923;
import net.minecraft.class_9334;

/**
 * Stateless predicate chain that decides whether a ground item should be protected.
 *
 * <p>All methods are static; this class is never instantiated.
 *
 * <p>Evaluation order (first match wins — early return):
 * <ol>
 *   <li>{@code item_overrides} BLACKLIST — always clear, overrides everything.</li>
 *   <li>{@code item_overrides} PROTECT — always protect, overrides everything.</li>
 *   <li>{@code protected_items} list — protect this specific item ID.</li>
 *   <li>{@code protected_namespaces} list — protect entire mod namespace.</li>
 *   <li>{@code namespace_tiers} map — PROTECT tier protects; all other tiers fall through.</li>
 *   <li>Vanilla {@link class_1814} check against {@code protect_rarity_minimum}.</li>
 *   <li>Enchanted item — protect if {@code protect_enchanted_items: true}.</li>
 *   <li>Custom name (anvil rename) — protect if {@code protect_named_items: true}.</li>
 *   <li>Player proximity — protect if within configured radius of any online player.</li>
 *   <li>Default — clear (return false).</li>
 * </ol>
 *
 * <p>Design note: The proximity check is intentionally last because it requires iterating
 * online players — O(players) — whereas rules 1–8 are O(1) lookups.
 */
public final class ItemFilters {

    private ItemFilters() {
        // Utility class — not instantiable
    }

    // ── Primary entry point ───────────────────────────────────────────────────

    /**
     * Returns {@code true} if the item entity should be protected from clearing,
     * {@code false} if it should be removed.
     *
     * @param entity the ground item being evaluated
     * @param world  the world in which the item lives (used for proximity check)
     * @param config the fully-resolved config for that world
     */
    public static boolean shouldProtect(class_1542 entity, class_3218 world, ResolvedConfig config) {
        class_1799 stack = entity.method_6983();
        if (stack.method_7960()) {
            // Discard ghost entities with empty stacks
            return false;
        }

        class_2960 id = getItemId(stack);

        // ── Rule 1 & 2: item_overrides (highest priority) ─────────────────────
        ItemTier explicitTier = config.itemOverrides.get(id.toString());
        if (explicitTier != null) {
            if (explicitTier.isBlacklisted()) return false; // Rule 1: always clear
            if (explicitTier.isProtected())   return true;  // Rule 2: always protect
            // LOW / NORMAL / HIGH fall through; tier affects priority, not binary protect
        }

        // ── Rule 3: protected_items list (exact ID match) ─────────────────────
        if (config.protectedItems.contains(id.toString())) {
            return true;
        }

        // ── Rule 4: protected_namespaces list ─────────────────────────────────
        if (config.protectedNamespaces.contains(id.method_12836())) {
            return true;
        }

        // ── Rule 5: namespace_tiers PROTECT entry ─────────────────────────────
        // Non-PROTECT tiers (LOW, NORMAL, HIGH) only affect clearing order — they
        // do not force protection or clearing on their own.
        ItemTier namespaceTier = config.namespaceTiers.get(id.method_12836());
        if (namespaceTier != null && namespaceTier.isProtected()) {
            return true;
        }

        // ── Rule 6: Vanilla Rarity check ──────────────────────────────────────
        class_1814 itemRarity = stack.method_57825(class_9334.field_50073, class_1814.field_8906);
        if (itemRarity.ordinal() >= config.protectRarityMinimum.ordinal()) {
            return true;
        }

        // ── Rule 7: Enchanted item ────────────────────────────────────────────
        if (config.protectEnchantedItems && stack.method_7942()) {
            return true;
        }

        // ── Rule 8: Custom name (anvil rename) ────────────────────────────────
        if (config.protectNamedItems && stack.method_57824(class_9334.field_49631) != null) {
            return true;
        }

        // ── Rule 9: Player proximity (most expensive — checked last) ──────────
        if (config.playerProximityRadius > 0 && isNearPlayer(entity, world, config.playerProximityRadius)) {
            return true;
        }

        // ── Rule 10: Default — clear ──────────────────────────────────────────
        return false;
    }

    // ── Helper methods ────────────────────────────────────────────────────────

    /**
     * Returns the registry {@link class_2960} for the item in the given stack.
     * Falls back to {@code minecraft:air} for unregistered or empty items.
     */
    public static class_2960 getItemId(class_1799 stack) {
        return class_7923.field_41178.method_10221(stack.method_7909());
    }

    /**
     * Returns the registry namespace string for the item in the given stack,
     * e.g., {@code "minecraft"}, {@code "cobblemon"}, {@code "create"}.
     */
    public static String getNamespace(class_1799 stack) {
        return getItemId(stack).method_12836();
    }

    /**
     * Returns {@code true} if the item entity is within {@code radiusBlocks} of any
     * online player in the same world.
     *
     * <p>Uses squared distance to avoid the sqrt call — {@code radiusSq = radius * radius}.
     */
    private static boolean isNearPlayer(class_1542 entity, class_3218 world, int radiusBlocks) {
        double radiusSq = (double) radiusBlocks * radiusBlocks;
        List<? extends class_1657> players = world.method_18456();

        for (class_1657 player : players) {
            if (player.method_5858(entity) <= radiusSq) {
                return true;
            }
        }
        return false;
    }
}
