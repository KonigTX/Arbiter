package com.bhd.autoclear.display;

import com.bhd.autoclear.config.ResolvedConfig;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_1259;
import net.minecraft.class_2561;
import net.minecraft.class_3213;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Manages the {@link class_3213} that shows the item-clear countdown to all online players.
 *
 * <p>Design decisions:
 * <ul>
 *   <li>Single shared bar instance — players are added/removed via
 *       {@link class_3213#method_14088} and {@link class_3213#method_14089}.
 *       This avoids the memory leak of creating one bar per player.</li>
 *   <li>Color graduation: GREEN at start → YELLOW at configured threshold → RED at final threshold.</li>
 *   <li>Players who join mid-countdown are added to the active bar via the
 *       {@code ServerPlayConnectionEvents.JOIN} event.</li>
 *   <li>The bar is dismissed (all players removed, reference nulled) after the clear executes
 *       or when {@link #dismiss()} is called explicitly (e.g., on config reload).</li>
 * </ul>
 */
public class BossBarHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger("AutoClear/BossBarHandler");

    /** The active bossbar, or {@code null} when no countdown is running. */
    private class_3213 activeBar = null;

    /** Total duration in seconds of the current countdown — used to compute fill percent. */
    private int totalSeconds = 0;

    // ── Registration ──────────────────────────────────────────────────────────

    /**
     * Registers the player-join event so late joiners see the bossbar mid-countdown.
     * Call once during mod initialization.
     */
    public void register() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3213 bar = activeBar;
            if (bar != null) {
                bar.method_14088(handler.field_14140);
            }
        });
        LOGGER.debug("BossBarHandler registered player-join event");
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    /**
     * Creates the countdown bossbar and adds all currently online players to it.
     * If a bar is already active (e.g., rapid force-clear), it is dismissed first.
     *
     * @param server       the Minecraft server instance (for player list access)
     * @param totalSec     total seconds for the countdown (matches {@code warning_start_seconds})
     * @param config       resolved config for bar style settings
     */
    public void startCountdown(MinecraftServer server, int totalSec, ResolvedConfig config) {
        dismiss(); // clean up any lingering bar

        totalSeconds = totalSec;
        class_2561 title = class_2561.method_43470("Items clearing in " + totalSec + "s");

        activeBar = new class_3213(title, class_1259.class_1260.field_5785, config.bossbarStyle);
        activeBar.method_5408(1.0f);
        activeBar.method_14091(true);

        for (class_3222 player : server.method_3760().method_14571()) {
            activeBar.method_14088(player);
        }

        LOGGER.debug("BossBar countdown started: {}s", totalSec);
    }

    /**
     * Updates the bossbar fill percentage and color based on remaining seconds.
     * Called once per world tick during the warning phase.
     *
     * @param server           server instance (for player list — handles mid-countdown joins
     *                         as a fallback; primary join handling is via the event)
     * @param secondsRemaining how many seconds remain until the clear
     * @param configuredTotal  total countdown seconds from config (for percent calculation)
     * @param config           resolved config for color thresholds
     */
    public void tick(MinecraftServer server, int secondsRemaining, int configuredTotal, ResolvedConfig config) {
        class_3213 bar = activeBar;
        if (bar == null) return;

        // Update fill percent — clamp to [0, 1]
        float percent = configuredTotal > 0
                ? Math.max(0.0f, Math.min(1.0f, (float) secondsRemaining / configuredTotal))
                : 0.0f;
        bar.method_5408(percent);

        // Update title to show live countdown
        bar.method_5413(class_2561.method_43470("Items clearing in " + secondsRemaining + "s"));

        // Color graduation: GREEN → YELLOW → RED
        class_1259.class_1260 newColor;
        if (secondsRemaining <= config.bossbarRedThresholdSeconds) {
            newColor = class_1259.class_1260.field_5784;
        } else if (secondsRemaining <= config.bossbarYellowThresholdSeconds) {
            newColor = class_1259.class_1260.field_5782;
        } else {
            newColor = class_1259.class_1260.field_5785;
        }

        if (bar.method_5420() != newColor) {
            bar.method_5416(newColor);
        }
    }

    /**
     * Removes all players from the bossbar and clears the reference.
     * Safe to call when no bar is active (no-op).
     */
    public void dismiss() {
        class_3213 bar = activeBar;
        if (bar == null) return;

        bar.method_14094();
        bar.method_14091(false);
        activeBar = null;
        totalSeconds = 0;

        LOGGER.debug("BossBar dismissed");
    }

    // ── State query ───────────────────────────────────────────────────────────

    /**
     * Returns {@code true} if a countdown bossbar is currently active.
     */
    public boolean isActive() {
        return activeBar != null;
    }
}
